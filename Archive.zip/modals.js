(function($) {

    const modalProto = {
        currentScrollPosition: null,
        $body: $('body'),
        transitionSpeed: 600,
        addedClass: 'modal--open',

        initProto() {
            const self = this;

            const triggerId = this.$element.attr('id');
            const $trigger = $(`[data-modal-id=${triggerId}]`);
            const $closeBtn = this.$element.find('[data-modal-close]');

            $trigger.on('click', function() {
                self.open();
            });

            $closeBtn.on('click', function() {
                self.close();
            });

        	$(window).on( "resize" , debounce(function() {
        		self.resize();
        	}, 250));
        },

        open() {
            this.currentScrollPosition = $(document).scrollTop();
            this.animateInModal();

            this.setAriaHidden(false);
        },

        close() {
            this.animateOutModal();
            this.setAriaHidden(true);
            $(document).scrollTop(this.currentScrollPosition);
            this.unsetPageHeight();
            this.unFixPage();
        },

        animateInModal() {
            const self = this,
                mobileAnimationIn = {
                    bottom: 0
                },
                desktopAnimationIn = "fadeIn";
            let animationIn = this.isDesktop() ? desktopAnimationIn : mobileAnimationIn;

            this.$element.velocity(animationIn, {
                duration: self.transitionSpeed,

                begin() {
                    self.$element.trigger("modalBeginOpening");
                    self.setHiddenPosition();
                    self.setBodyTopGap();
                },
                complete() {
                    self.fixPage();
                    self.setPageHeight();
                    self.setModalBodyHeight();
                    self.$element.addClass(self.addedClass);
                    self.$element.trigger("modalCompleteOpening");

                }
            });
        },

        animateOutModal($modal = this.$element) {
            const self = this;
            const modalHeight = $modal.outerHeight();
            const mobileAnimationOut = {
                bottom: -modalHeight
            };
            const desktopAnimationOut = "fadeOut";
            let animationOut = this.isDesktop() ? desktopAnimationOut : mobileAnimationOut;

            $modal.velocity(animationOut, {
                duration: self.transitionSpeed,
                begin() {
                    $modal.trigger("modalBeginClosing");
                    $modal.removeClass(self.addedClass);
                },
                complete() {
                    $modal.trigger("modalCompleteClosing");
                    self.resetModalStyling();
                    self.$body.removeClass("no-scroll");
                }
            });
        },

        setHiddenPosition() {
            const modalHeight = this.$element.outerHeight();
            if (this.isDesktop()) {
                this.$element.css({
                    "bottom": "auto",
                    "display": "block",
                    "visibility": "visible" // allows the height of the header to be calculated
                });
            } else {
                this.$element.css({
                    bottom: -modalHeight,
                    display: "block"
                });
            }
        },

        resetModalStyling() {
        	this.$element.removeAttr("style");
        	this.$element.find(".modal__body").removeAttr("style");
        },

        setAriaHidden(boolean) {
            this.$element.attr("aria-hidden", boolean);
        },

        fixPage() {
            this.$body.addClass("no-scroll");
        },

        unFixPage() {
            this.$body.removeClass("no-scroll");
        },

        setPageHeight() {
            const windowHeight = window.innerHeight || $(window).height();
            this.$body.css({
                height: windowHeight
            });
        },

        unsetPageHeight() {
            this.$body.css({
                height: "auto"
            });
        },

        isDesktop() {
            return $(window).width() > 768 ? true : false;
        },

        getHeaderHeight() {
        	const 
        		$header = this.$element.find('.modal__header'),
        		headerHeight = $header.outerHeight();

        	return headerHeight;
        },

        bodyTranslateAmount() {
        	const translateSetting = `translateY(${this.getHeaderHeight()}px)`;
        	return {
        		"transform": translateSetting,
				"-webkit-transform": translateSetting,
				"-ms-transform": translateSetting,
				"-moz-transform": translateSetting,
				"-o-transform": translateSetting
        	}
        },

        setBodyTopGap() {
    		const $modalBody = this.$element.find('.modal__body');
        	$modalBody.css(
				this.bodyTranslateAmount()
        	);
        },

		setModalBodyHeight() {
			const $modalBody = this.$element.find( ".modal__body" );
            const modalBodyHeightSettings = this.isDesktop() ? this.desktopHeightSettings() : this.mobileHeightSettings();
			
			$modalBody.css(modalBodyHeightSettings);
        },

        resize() {
			if (this.$element.hasClass(this.addedClass)) {
				this.isDesktop();
				this.setPageHeight();
				this.setModalBodyHeight();
				this.setBodyTopGap();
				this.$element.trigger('modalResize');
			}
        }
    };

    $.fn.standardModal = function(options) {
        this.each(function() {
           
           	// Set defaults
           	const defaults = {

            }

			// Take modal data from prototype
            const modal = Object.create(modalProto);
            modal.$element = $(this);
            modal.initProto();
			
            modal.mobileHeightSettings = function() {
            	const $modalBody = modal.$element.find( ".modal__body" );
            	const bodyHeight = ( window.innerHeight || $(window).height() ) - modal.getHeaderHeight();

				return {
					height: bodyHeight,
					maxHeight: "none"
				}
            };

            modal.desktopHeightSettings = function() {
            	const $modalBody = modal.$element.find( ".modal__body" );
            	const eightyPercentScreen = ( window.innerHeight || $(window).height() ) * 0.8;
            	const bodyHeight =  eightyPercentScreen - modal.getHeaderHeight();

            	return {
					height: "auto",
					maxHeight: bodyHeight
            	}
            };
        });
    };

    $.fn.wideModal = function(options) {
	    this.each(function() {
           
           	// Set defaults
           	const defaults = {

            }

			// Take modal data from prototype
            const modal = Object.create(modalProto);
            modal.$element = $(this);
            modal.initProto();

            const getFooterHeight = function() {
				const $footer = modal.$element.find('.modal__footer');
				return $footer.outerHeight();
            };
            
            modal.mobileHeightSettings = function() {
            	const $modalBody = modal.$element.find( ".modal__body" );
            	const bodyHeight = ( window.innerHeight || $(window).height() ) - modal.getHeaderHeight();

				return {
					height: bodyHeight,
					maxHeight: "none"
				}
            };

            modal.desktopHeightSettings = function() {
            	const $modalBody = modal.$element.find( ".modal__body" );
            	const eightyPercentScreen = ( window.innerHeight || $(window).height() ) * 0.8;
            	const bodyHeight =  eightyPercentScreen - modal.getHeaderHeight();

            	return {
					height: "auto",
					maxHeight: bodyHeight
            	}
            };
        });
    };

    $(document).ready(function() {
        $('div[data-modal="standard"]').standardModal();
        $('div[data-modal="wide"]').wideModal();
    });
}(jQuery));
